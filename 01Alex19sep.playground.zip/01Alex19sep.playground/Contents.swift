import UIKit
/*En un comentario de una linea escribe tu nombre de pila
En un comentario multilinea escribe tu nombre de pila, tu carrera y tu edad
Declara una variable de tipo string, booleano y entero y asigna un valor para cada una
Declara 4 variables sin asignarles un valor
Declara 4 variables de cualquier tipo y asigna un valor para cada una de ellas
Declara las variables necesarias para almacenar tu nombre de pila, tu apellido , tu edad diferenciando entre var y let
Realiza los ejercicios 3,4 y 5 agregando el tipado explicito*/

//Enrique
/*
 Enrique
 Mac
 23
 */

var materia = "Programacion"
var aprobadi = true
var calificacion = 8

//Ejercicio4
var usuarios : String?
var promedio : Float?
var nacionalidad :String?
var numeroCuenta : Int?

//Ejercicio5 cambiarlo con la foto 
var precision = 9.5
var color = "amarillo"
var prueba = true
var altura = 1.70

//Ejercicio6
let nombre = "Enrique"
let apellido = "Pavon"
var edad = 23

var usuario : String = "alex"
var promedios : Float = 8.6
var nacionalidads : String = "mexicano"
var numeroCueta : Int = 123





